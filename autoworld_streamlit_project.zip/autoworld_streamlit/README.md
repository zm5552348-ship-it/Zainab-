# AutoWorld — The World of Automobiles

A Python web application built with Streamlit for an educational automobile project.

## Features
- Home page with automobile definition and introduction
- Seven vehicle categories with images and descriptions
- Petrol, diesel, hybrid, and electric power comparison table
- Automotive history milestones (Karl Benz and Henry Ford)
- Contact form with basic validation (demo only; it does not send email)
- Responsive layout and navigation

## Run locally
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud
1. Create a GitHub repository and upload `app.py`, `requirements.txt`, and `README.md`.
2. Visit https://share.streamlit.io/ and sign in with GitHub.
3. Choose **Create app**, select your repository, branch (usually `main`), and main file path `app.py`.
4. Click **Deploy**. Streamlit will install the dependencies from `requirements.txt`.
5. When deployment finishes, open the generated public app URL.

## GitHub upload from an iPhone
1. Sign in at https://github.com/ and create a new repository named `autoworld-streamlit`.
2. Choose public or private according to your assignment, then create it.
3. Open the repository, choose **Add file → Upload files**, and upload the three files from this project.
4. Commit the upload, then follow the Streamlit Community Cloud steps above.

## Notes
- Car photographs are loaded from Unsplash URLs and require an internet connection.
- The contact form validates fields in the browser session but does not send or store messages.
- This project does not include API keys or secrets.
