import streamlit as st
import pandas as pd

st.set_page_config(page_title="AutoWorld | Automobile Atlas", page_icon="🚘", layout="wide")

NAVY = "#0B1F33"
RED = "#E63946"
SILVER = "#C0C7CE"

st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700;800&family=Open+Sans:wght@400;500;600&display=swap');
html, body, [class*="css"] {{ font-family: 'Open Sans', sans-serif; }}
h1,h2,h3 {{ font-family: 'Montserrat', sans-serif; }}
.stApp {{ background: #f4f6f8; }}
section[data-testid="stSidebar"] {{ background: {NAVY}; }}
section[data-testid="stSidebar"] * {{ color: white !important; }}
.hero {{ padding: 2.6rem 2.4rem; border-radius: 22px; color: white;
background: linear-gradient(100deg, rgba(11,31,51,.96), rgba(11,31,51,.72)), url('https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1800&q=85') center/cover; }}
.eyebrow {{ color: {RED}; font-weight: 800; letter-spacing: .16em; text-transform: uppercase; font-size: .78rem; }}
.pill {{ display:inline-block; padding:.35rem .7rem; border-radius:999px; background:#e9eef3; color:{NAVY}; font-size:.82rem; margin: .2rem .25rem .2rem 0; }}
.car-card {{ background:white; border:1px solid #e4e9ee; border-radius:16px; padding:1rem; height:100%; box-shadow:0 5px 18px rgba(11,31,51,.05); }}
.small-muted {{ color:#5b6875; font-size:.95rem; }}
div.stButton > button {{ background:{RED}; color:white; border:0; border-radius:10px; font-weight:700; }}
div.stButton > button:hover {{ background:#c92d3a; color:white; }}
</style>
""", unsafe_allow_html=True)

cars = [
    {"Type":"Sedan","Description":"A comfortable passenger car, usually with four doors and a separate trunk.","Best for":"Everyday commuting","Image":"https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=900&q=80"},
    {"Type":"Hatchback","Description":"A compact car with a rear door that opens upward and flexible cargo space.","Best for":"City driving","Image":"https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=900&q=80"},
    {"Type":"SUV","Description":"A versatile vehicle with a raised driving position and a spacious interior.","Best for":"Families and trips","Image":"https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=900&q=80"},
    {"Type":"Coupe","Description":"A sleek, sporty car traditionally designed with two doors.","Best for":"Style and performance","Image":"https://images.unsplash.com/photo-1614200187524-dc4b892acf16?auto=format&fit=crop&w=900&q=80"},
    {"Type":"Convertible","Description":"A car with a folding or removable roof for open-air driving.","Best for":"Scenic drives","Image":"https://images.unsplash.com/photo-1504215680853-026ed2a45def?auto=format&fit=crop&w=900&q=80"},
    {"Type":"Van","Description":"A roomy vehicle for transporting passengers, equipment, or cargo.","Best for":"Groups and business","Image":"https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=900&q=80"},
    {"Type":"Pickup Truck","Description":"A vehicle with an open rear cargo bed for tools, supplies, and goods.","Best for":"Utility and hauling","Image":"https://images.unsplash.com/photo-1551830820-330a71b99659?auto=format&fit=crop&w=900&q=80"},
]
power = pd.DataFrame([
    {"Power type":"Petrol","How it works":"Gasoline engine burns fuel to create motion.","Advantages":"Widely available; familiar refueling.","Considerations":"Fuel costs and exhaust emissions."},
    {"Power type":"Diesel","How it works":"Diesel engine uses compression ignition.","Advantages":"Strong pulling power; often efficient on long trips.","Considerations":"Nitrogen oxide and particulate emissions."},
    {"Power type":"Hybrid","How it works":"Combines an engine with an electric motor and battery.","Advantages":"Can improve fuel economy, especially in stop-start traffic.","Considerations":"More complex powertrain."},
    {"Power type":"Electric","How it works":"Battery supplies electricity to an electric motor.","Advantages":"No tailpipe emissions; quiet operation.","Considerations":"Charging access, charging time, and range."},
])

with st.sidebar:
    st.markdown("## 🚘 AutoWorld")
    st.caption("THE WORLD OF AUTOMOBILES")
    page = st.radio("Navigate", ["Home", "Car Types", "History", "Contact"], label_visibility="collapsed")
    st.markdown("---")
    st.caption("An educational automobile atlas")
    st.markdown("<span class='pill'>Modern</span><span class='pill'>Accessible</span>", unsafe_allow_html=True)

if page == "Home":
    st.markdown("""
    <div class="hero">
      <div class="eyebrow">Explore • Learn • Drive</div>
      <h1 style="font-size:clamp(2.3rem,5vw,4rem);line-height:1.08;margin:.65rem 0;color:white">Discover the World<br>of Automobiles</h1>
      <p style="font-size:1.12rem;max-width:680px;color:#edf2f7">Explore the vehicles that move our world, from classic designs to modern electric innovation.</p>
    </div>
    """, unsafe_allow_html=True)
    st.write("")
    left, right = st.columns([1.2, 1])
    with left:
        st.markdown("### What is an automobile?")
        st.write("An automobile is a motorized road vehicle designed primarily to transport people or goods. Automobiles have evolved from early engine-powered inventions into advanced vehicles using petrol, diesel, hybrid, and electric power.")
        if st.button("Explore car types →", use_container_width=True):
            st.session_state["jump"] = "Car Types"
            st.rerun()
    with right:
        st.image("https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1200&q=85", caption="Automotive design keeps evolving", use_container_width=True)
    st.markdown("### Why automobiles matter")
    a,b,c = st.columns(3)
    for col, icon, title, desc in [
        (a,"🛣️","Mobility","Connect people to work, education, healthcare, and communities."),
        (b,"📦","Commerce","Move goods and support businesses, services, and supply chains."),
        (c,"⚡","Innovation","Drive advances in safety, efficiency, connectivity, and clean energy.")
    ]:
        with col:
            st.markdown(f"<div class='car-card'><div style='font-size:2rem'>{icon}</div><h3>{title}</h3><p class='small-muted'>{desc}</p></div>", unsafe_allow_html=True)
    st.markdown("### At a glance")
    m1,m2,m3 = st.columns(3)
    m1.metric("Vehicle categories", "7")
    m2.metric("Power types", "4")
    m3.metric("History milestones", "2")

elif page == "Car Types":
    st.markdown("<div class='eyebrow'>Find your fit</div>", unsafe_allow_html=True)
    st.title("Car Types")
    st.write("Different body styles are designed for different needs, from compact city travel to family journeys and heavy-duty work.")
    query = st.text_input("Search vehicle types", placeholder="Try SUV, city, family, cargo…")
    filtered = [car for car in cars if query.lower() in (car["Type"] + " " + car["Description"] + " " + car["Best for"]).lower()]
    grid = st.columns(3)
    if not filtered:
        st.info("No matching vehicle type. Try another search.")
    for i, car in enumerate(filtered):
        with grid[i % 3]:
            st.markdown("<div class='car-card'>", unsafe_allow_html=True)
            st.image(car["Image"], caption=car["Type"], use_container_width=True)
            st.markdown(f"### {car['Type']}")
            st.write(car["Description"])
            st.markdown(f"<span class='pill'>Best for: {car['Best for']}</span>", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)
            st.write("")
    st.markdown("---")
    st.markdown("<div class='eyebrow'>Powertrain basics</div>", unsafe_allow_html=True)
    st.title("How Automobiles Are Powered")
    st.dataframe(power, use_container_width=True, hide_index=True)
    st.caption("Note: real-world efficiency and emissions depend on the vehicle, driving conditions, and local electricity or fuel supply.")

elif page == "History":
    st.markdown("<div class='eyebrow'>Milestones that moved us</div>", unsafe_allow_html=True)
    st.title("Automotive History")
    st.write("A short timeline of two important turning points in automobile development.")
    st.markdown("""
    <div style="border-left:4px solid #E63946;padding-left:1.4rem;margin:1.5rem 0">
      <div class="eyebrow">1885–1886</div>
      <h2>Karl Benz and the Patent-Motorwagen</h2>
      <p>Karl Benz developed his three-wheeled Patent-Motorwagen in 1885 and received a patent in 1886. It became a landmark in the development of the practical, engine-powered automobile.</p>
    </div>
    """, unsafe_allow_html=True)
    st.image("https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=1400&q=80", caption="Automobile engineering has changed dramatically since the earliest motor cars.", use_container_width=True)
    st.markdown("""
    <div style="border-left:4px solid #E63946;padding-left:1.4rem;margin:1.5rem 0">
      <div class="eyebrow">1913</div>
      <h2>Henry Ford and the Moving Assembly Line</h2>
      <p>Ford Motor Company introduced the moving assembly line for automobile production at its Highland Park plant in 1913. The process increased production efficiency and helped make cars more affordable to a wider public.</p>
    </div>
    """, unsafe_allow_html=True)
    st.info("Big idea: the automobile evolved through both engineering breakthroughs and changes in how vehicles were manufactured.")

elif page == "Contact":
    st.markdown("<div class='eyebrow'>Questions or feedback?</div>", unsafe_allow_html=True)
    st.title("Get in Touch")
    st.write("Send a message to the AutoWorld project team.")
    with st.form("contact_form", clear_on_submit=True):
        name = st.text_input("Name *", placeholder="Your full name")
        email = st.text_input("Email *", placeholder="you@example.com")
        message = st.text_area("Message *", placeholder="Write your message here…", height=150)
        submitted = st.form_submit_button("Send Message")
        if submitted:
            if not name.strip() or not email.strip() or not message.strip():
                st.error("Please complete all required fields.")
            elif "@" not in email or "." not in email.rsplit("@", 1)[-1]:
                st.error("Please enter a valid email address.")
            else:
                st.success("Thanks! Your form passed validation. This demo does not send or store email messages yet.")
                st.caption("To receive messages, connect this form to a secure backend or form service.")
    st.markdown("---")
    st.caption("AutoWorld is an educational student project.")

st.markdown("---")
st.caption("© AutoWorld • The World of Automobiles | Educational project")
